#ifndef _HGIC_TICKER_API_H_
#define _HGIC_TICKER_API_H_

void delay_us(uint32 n);

#endif
