#ifndef __IP101G_H_
#define __IP101G_H_

extern struct ethernet_phy_driver ip101g_driver;


#endif
