#ifndef __RTL8201F_H_
#define __RTL8201F_H_

extern struct ethernet_phy_driver rtl8201f_driver;


#endif
