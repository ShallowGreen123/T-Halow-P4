#ifndef __SOC_H__
#define __SOC_H__

#include "tx_platform.h"

#ifdef RTOS_ENABLE
#define CONFIG_KERNEL_RHINO 1
#endif
#define SYSTEM_CLOCK DEFAULT_SYS_CLK

#endif